﻿using Microsoft.AspNetCore.Mvc;

namespace SV22T1020811.Admin.Controllers
{
    /// <summary>
    /// Controller quản lý tài khoản người dùng
    /// Bao gồm: đăng nhập, đăng xuất và đổi mật khẩu
    /// </summary>
    public partial class AccountController : Controller
    {
        /// <summary>
        /// Hiển thị giao diện đăng nhập
        /// </summary>
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        /// <summary>
        /// Xử lý đăng nhập (kiểm tra username và password)
        /// Hiện tại chỉ dùng để test, chưa kết nối database
        /// </summary>
        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            // TODO: Kiểm tra tài khoản từ database

            return RedirectToAction("Index", "Home");
        }

        /// <summary>
        /// Đăng xuất khỏi hệ thống
        /// Xóa Session hoặc Cookie xác thực
        /// </summary>
        public IActionResult Logout()
        {
            // TODO: Xóa Session/Cookie

            return RedirectToAction("Login");
        }

        /// <summary>
        /// Hiển thị giao diện đổi mật khẩu
        /// </summary>
        public IActionResult ChangePassword()
        {
            return View();
        }
    }
}