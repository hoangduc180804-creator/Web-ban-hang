﻿using Microsoft.AspNetCore.Mvc;

namespace SV22T1020811.Admin.Controllers
{
    /// <summary>
    /// Controller quản lý nhà cung cấp
    /// Bao gồm: danh sách, thêm mới, chỉnh sửa và xóa
    /// </summary>
    public class SupplierController : Controller
    {

        /// <summary>
        /// Hiển thị danh sách nhà cung cấp
        /// Có thể tích hợp tìm kiếm và phân trang
        /// </summary>
        public IActionResult Index(string keyword = "", int page = 1)
        {
            // TODO: Thực hiện tìm kiếm & phân trang
            return View();
        }

        /// <summary>
        /// Hiển thị giao diện bổ sung nhà cung cấp mới
        /// Sử dụng chung View Edit
        /// </summary>
        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.Title = "Bổ sung nhà cung cấp";
            return View("Edit");
        }

        /// <summary>
        /// Xử lý lưu nhà cung cấp mới
        /// </summary>
        [HttpPost]
        public IActionResult Create(object model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Title = "Bổ sung nhà cung cấp";
                return View("Edit", model);
            }

            // TODO: Lưu nhà cung cấp vào CSDL
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hiển thị giao diện chỉnh sửa thông tin nhà cung cấp
        /// </summary>
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Title = "Cập nhật thông tin nhà cung cấp";

            // TODO: Lấy dữ liệu nhà cung cấp theo id
            return View();
        }

        /// <summary>
        /// Xử lý cập nhật thông tin nhà cung cấp
        /// </summary>
        [HttpPost]
        public IActionResult Edit(int id, object model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Title = "Cập nhật thông tin nhà cung cấp";
                return View(model);
            }

            // TODO: Cập nhật dữ liệu
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hiển thị xác nhận xóa nhà cung cấp
        /// </summary>
        [HttpGet]
        public IActionResult Delete(int id)
        {
            // TODO: Lấy thông tin để hiển thị xác nhận
            return View();
        }

        /// <summary>
        /// Xử lý xóa nhà cung cấp khỏi hệ thống
        /// </summary>
        [HttpPost]
        public IActionResult Delete(int id, string confirm = "")
        {
            // TODO: Thực hiện xóa
            return RedirectToAction("Index");
        }
    }
}