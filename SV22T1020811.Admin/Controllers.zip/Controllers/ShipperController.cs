﻿using Microsoft.AspNetCore.Mvc;

namespace SV22T1020811.Admin.Controllers
{
    /// <summary>
    /// Controller quản lý người giao hàng (Shipper)
    /// Bao gồm: danh sách, thêm mới, chỉnh sửa và xóa
    /// </summary>
    public class ShipperController : Controller
    {
        /// <summary>
        /// Hiển thị danh sách người giao hàng
        /// </summary>
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Hiển thị giao diện bổ sung người giao hàng
        /// </summary>
        public IActionResult Create()
        {
            ViewBag.Title = "Bổ sung người giao hàng";
            return View();
        }

        /// <summary>
        /// Hiển thị giao diện cập nhật thông tin người giao hàng theo id
        /// </summary>
        public IActionResult Edit(int id)
        {
            ViewBag.Title = "Cập nhật thông tin người giao hàng";

            // TODO: Lấy dữ liệu Shipper theo id truyền vào View
            return View();
        }

        /// <summary>
        /// Hiển thị giao diện xác nhận xóa người giao hàng
        /// </summary>
        public IActionResult Delete(int id)
        {
            // TODO: Lấy thông tin Shipper để hiển thị xác nhận
            return View();
        }
    }
}