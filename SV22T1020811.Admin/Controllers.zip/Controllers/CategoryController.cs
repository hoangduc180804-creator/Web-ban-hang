﻿using Microsoft.AspNetCore.Mvc;

namespace SV22T1020811.Admin.Controllers
{
    /// <summary>
    /// Controller quản lý loại hàng (Category)
    /// Bao gồm: danh sách, thêm, sửa và xóa
    /// </summary>
    public class CategoryController : Controller
    {       
        /// <summary>
        /// Hiển thị danh sách tất cả loại hàng
        /// </summary>
        public IActionResult Index()
        {
            // TODO: Lấy danh sách loại hàng từ CSDL
            return View();
        }

        /// <summary>
        /// Hiển thị form bổ sung loại hàng mới
        /// </summary>
        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.Title = "Bổ sung loại hàng";
            return View();
        }

        /// <summary>
        /// Xử lý lưu loại hàng mới vào hệ thống
        /// </summary>
        [HttpPost]
        public IActionResult Create(object model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // TODO: Lưu loại hàng vào CSDL
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hiển thị form cập nhật loại hàng theo id
        /// </summary>
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Title = "Cập nhật loại hàng";

            // TODO: Lấy dữ liệu loại hàng theo id
            return View();
        }

        /// <summary>
        /// Xử lý cập nhật thông tin loại hàng
        /// </summary>
        [HttpPost]
        public IActionResult Edit(int id, object model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // TODO: Cập nhật dữ liệu
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hiển thị xác nhận xóa loại hàng
        /// </summary>
        [HttpGet]
        public IActionResult Delete(int id)
        {
            // TODO: Lấy thông tin loại hàng để hiển thị
            return View();
        }

        /// <summary>
        /// Xử lý xóa loại hàng khỏi hệ thống
        /// </summary>
        [HttpPost]
        public IActionResult Delete(int id, string confirm = "")
        {
            // TODO: Thực hiện xóa
            return RedirectToAction("Index");
        }
    }
}