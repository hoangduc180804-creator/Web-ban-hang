﻿using Microsoft.AspNetCore.Mvc;

namespace SV22T1020811.Admin.Controllers
{
    /// <summary>
    /// Controller quản lý khách hàng trong hệ thống
    /// Bao gồm: danh sách, thêm, sửa, xóa và đổi mật khẩu
    /// </summary>
    public class CustomerController : Controller
    {

        /// <summary>
        /// Hiển thị danh sách khách hàng
        /// Có hỗ trợ tìm kiếm và phân trang
        /// </summary>
        public IActionResult Index(string keyword = "", int page = 1)
        {
            // TODO: Thực hiện tìm kiếm & phân trang
            return View();
        }

        /// <summary>
        /// Hiển thị form bổ sung khách hàng mới
        /// </summary>
        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.Title = "Bổ sung khách hàng";
            return View();
        }

        /// <summary>
        /// Xử lý lưu khách hàng mới vào hệ thống
        /// </summary>
        [HttpPost]
        public IActionResult Create(object model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // TODO: Lưu khách hàng vào CSDL
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hiển thị form cập nhật thông tin khách hàng theo id
        /// </summary>
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Title = "Cập nhật thông tin khách hàng";

            // TODO: Lấy dữ liệu khách hàng theo id
            return View();
        }

        /// <summary>
        /// Xử lý cập nhật thông tin khách hàng
        /// </summary>
        [HttpPost]
        public IActionResult Edit(int id, object model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // TODO: Cập nhật dữ liệu
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hiển thị xác nhận xóa khách hàng
        /// </summary>
        [HttpGet]
        public IActionResult Delete(int id)
        {
            // TODO: Lấy thông tin khách hàng để hiển thị
            return View();
        }

        /// <summary>
        /// Xử lý xóa khách hàng khỏi hệ thống
        /// </summary>
        [HttpPost]
        public IActionResult Delete(int id, string confirm = "")
        {
            // TODO: Thực hiện xóa
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hiển thị form thay đổi mật khẩu khách hàng
        /// </summary>
        [HttpGet]
        public IActionResult ChangePassword(int id)
        {
            ViewBag.Title = "Thay đổi mật khẩu khách hàng";
            return View();
        }

        /// <summary>
        /// Xử lý cập nhật mật khẩu mới cho khách hàng
        /// </summary>
        [HttpPost]
        public IActionResult ChangePassword(int id, string newPassword)
        {
            // TODO: Cập nhật mật khẩu
            return RedirectToAction("Index");
        }
    }
}