﻿using Microsoft.AspNetCore.Mvc;

namespace SV22T1020811.Admin.Controllers
{
    /// <summary>
    /// Controller quản lý nhân viên trong hệ thống
    /// Bao gồm: thêm, sửa, xóa, đổi mật khẩu và phân quyền
    /// </summary>
    public class EmployeeController : Controller
    {
        /// <summary>
        /// Hiển thị danh sách tất cả nhân viên
        /// </summary>
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Hiển thị form bổ sung nhân viên mới
        /// </summary>
        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.Title = "Bổ sung nhân viên";
            return View();
        }

        /// <summary>
        /// Xử lý lưu thông tin nhân viên mới
        /// </summary>
        [HttpPost]
        public IActionResult Create(object model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // TODO: Lưu nhân viên vào CSDL
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hiển thị form cập nhật thông tin nhân viên theo id
        /// </summary>
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Title = "Cập nhật thông tin nhân viên";
            return View();
        }

        /// <summary>
        /// Xử lý cập nhật thông tin nhân viên
        /// </summary>
        [HttpPost]
        public IActionResult Edit(int id, object model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // TODO: Cập nhật nhân viên
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hiển thị xác nhận xóa nhân viên
        /// </summary>
        [HttpGet]
        public IActionResult Delete(int id)
        {
            return View();
        }

        /// <summary>
        /// Xử lý xóa nhân viên khỏi hệ thống
        /// </summary>
        [HttpPost]
        public IActionResult Delete(int id, string confirm = "")
        {
            // TODO: Thực hiện xóa
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hiển thị form đổi mật khẩu của nhân viên
        /// </summary>
        [HttpGet]
        public IActionResult ChangePassword(int id)
        {
            ViewBag.Title = "Đổi mật khẩu nhân viên";
            return View();
        }

        /// <summary>
        /// Xử lý cập nhật mật khẩu mới cho nhân viên
        /// </summary>
        [HttpPost]
        public IActionResult ChangePassword(int id, string newPassword)
        {
            // TODO: Cập nhật mật khẩu
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hiển thị form phân quyền cho nhân viên
        /// </summary>
        [HttpGet]
        public IActionResult ChangeRole(int id)
        {
            ViewBag.Title = "Phân quyền nhân viên";
            return View();
        }

        /// <summary>
        /// Xử lý cập nhật quyền (role) của nhân viên
        /// </summary>
        [HttpPost]
        public IActionResult ChangeRole(int id, int roleId)
        {
            // TODO: Cập nhật quyền
            return RedirectToAction("Index");
        }
    }
}