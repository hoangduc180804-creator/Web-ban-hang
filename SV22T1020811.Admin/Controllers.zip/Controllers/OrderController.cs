﻿using Microsoft.AspNetCore.Mvc;

namespace SV22T1020811.Admin.Controllers
{
    /// <summary>
    /// Controller quản lý đơn hàng và xử lý các trạng thái đơn hàng
    /// </summary>
    public class OrderController : Controller
    {

        /// <summary>
        /// Hiển thị danh sách tất cả đơn hàng
        /// </summary>
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Tìm kiếm đơn hàng theo điều kiện (mã đơn, khách hàng, trạng thái...)
        /// </summary>
        public IActionResult Search(string keyword = "", int status = 0)
        {
            // TODO: Thực hiện tìm kiếm
            return View("Index");
        }

        /// <summary>
        /// Hiển thị form tạo đơn hàng mới
        /// </summary>
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Xử lý lưu đơn hàng mới
        /// </summary>
        [HttpPost]
        public IActionResult Create(object model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // TODO: Lưu đơn hàng
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hiển thị chi tiết đơn hàng theo id điều hướng đến các chức năng để xử lý
        /// </summary>
        public IActionResult Detail(int id)
        {
            // TODO: Lấy thông tin đơn hàng và danh sách sản phẩm
            return View();
        }

        /// <summary>
        /// Thêm một sản phẩm vào giỏ hàng của đơn hàng 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="productId"></param>
        /// <returns></returns>
        public IActionResult AddCartItem(int id = 0, int productId = 0, int quantity = 0)
        {
            return View();
        }
            /// <summary>
            /// Cập nhật số lượng sản phẩm trong giỏ hàng của đơn hàng
            /// </summary>
            /// param name="id">xử lý giỏ hàng</param>
            /// param name="productId">id sản phẩm cần cập nhật</param>
            /// returns></returns>
            [HttpPost]
        public IActionResult EditCartItem(int id, int productId, int quantity)
        {
            // TODO: Cập nhật số lượng sản phẩm
            return RedirectToAction("Detail", new { id = id });
        }

        /// <summary>
        /// Xóa một sản phẩm khỏi giỏ hàng của đơn hàng
        /// </summary>
        [HttpPost]
        public IActionResult DeleteCartItem(int id, int productId)
        {
            // TODO: Xóa sản phẩm khỏi đơn hàng
            return RedirectToAction("Detail", new { id = id });
        }

        /// <summary>
        /// Xóa toàn bộ sản phẩm trong giỏ hàng hiện tại
        /// </summary>
        public IActionResult ClearCart()
        {
            // TODO: Xóa toàn bộ giỏ hàng
            return RedirectToAction("Create");
        }

        /// <summary>
        /// Xác nhận đơn hàng (đơn chuyển sang trạng thái đã duyệt)
        /// </summary>
        public IActionResult Accept(int id)
        {
            // TODO: Cập nhật trạng thái đơn hàng
            return RedirectToAction("Detail", new { id = id });
        }

        /// <summary>
        /// Chuyển đơn hàng sang trạng thái đang giao
        /// </summary>
        public IActionResult Shipping(int id)
        {
            // TODO: Cập nhật trạng thái giao hàng
            return RedirectToAction("Detail", new { id = id });
        }

        /// <summary>
        /// Hoàn tất đơn hàng (đã giao thành công)
        /// </summary>
        public IActionResult Finish(int id)
        {
            // TODO: Cập nhật trạng thái hoàn tất
            return RedirectToAction("Detail", new { id = id });
        }

        /// <summary>
        /// Từ chối đơn hàng (khi chưa xử lý)
        /// </summary>
        public IActionResult Reject(int id)
        {
            // TODO: Cập nhật trạng thái từ chối
            return RedirectToAction("Detail", new { id = id });
        }

        /// <summary>
        /// Hủy đơn hàng (theo yêu cầu khách hoặc hệ thống)
        /// </summary>
        public IActionResult Cancel(int id)
        {
            // TODO: Cập nhật trạng thái hủy
            return RedirectToAction("Detail", new { id = id });
        }

        /// <summary>
        /// Xóa đơn hàng khỏi hệ thống (chỉ áp dụng khi được phép)
        /// </summary>
        public IActionResult Delete(int id)
        {
            // TODO: Thực hiện xóa đơn hàng
            return RedirectToAction("Index");
        }
    }
}