﻿using Microsoft.AspNetCore.Mvc;

namespace SV22T1020811.Admin.Controllers
{
    /// <summary>
    /// Controller quản lý sản phẩm, thuộc tính và hình ảnh của sản phẩm
    /// </summary>
    public class ProductController : Controller
    {
        #region PRODUCT

        /// <summary>
        /// Hiển thị danh sách tất cả sản phẩm
        /// URL: Product/Index
        /// </summary>
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Hiển thị form thêm mới sản phẩm
        /// URL: Product/Create (GET)
        /// </summary>
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Xử lý lưu thông tin sản phẩm mới vào hệ thống
        /// URL: Product/Create (POST)
        /// </summary>
        [HttpPost]
        public IActionResult Create(object model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // TODO: Lưu dữ liệu sản phẩm

            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hiển thị form cập nhật sản phẩm theo id
        /// URL: Product/Edit/{id} (GET)
        /// </summary>
        [HttpGet]
        public IActionResult Edit(int id)
        {
            // TODO: Lấy dữ liệu theo id
            return View();
        }

        /// <summary>
        /// Xử lý cập nhật thông tin sản phẩm
        /// URL: Product/Edit/{id} (POST)
        /// </summary>
        [HttpPost]
        public IActionResult Edit(int id, object model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // TODO: Cập nhật dữ liệu

            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hiển thị xác nhận xóa sản phẩm
        /// URL: Product/Delete/{id} (GET)
        /// </summary>
        [HttpGet]
        public IActionResult Delete(int id)
        {
            // TODO: Lấy thông tin sản phẩm để xác nhận
            return View();
        }

        /// <summary>
        /// Thực hiện xóa sản phẩm khỏi hệ thống
        /// URL: Product/Delete/{id} (POST)
        /// </summary>
        [HttpPost]
        public IActionResult Delete(int id, string confirm = "")
        {
            // TODO: Thực hiện xóa

            return RedirectToAction("Index");
        }

        #endregion

        #region ATTRIBUTE

        /// <summary>
        /// Hiển thị danh sách thuộc tính của một sản phẩm
        /// URL: Product/ListAttributes/{id}
        /// </summary>
        public IActionResult ListAttributes(int id)
        {
            return View();
        }

        /// <summary>
        /// Hiển thị form thêm thuộc tính cho sản phẩm
        /// URL: Product/CreateAttribute/{id} (GET)
        /// </summary>
        [HttpGet]
        public IActionResult CreateAttribute(int id)
        {
            return View();
        }

        /// <summary>
        /// Xử lý lưu thuộc tính mới cho sản phẩm
        /// URL: Product/CreateAttribute/{id} (POST)
        /// </summary>
        [HttpPost]
        public IActionResult CreateAttribute(int id, object model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // TODO: Lưu thuộc tính

            return RedirectToAction("ListAttributes", new { id = id });
        }

        /// <summary>
        /// Hiển thị form cập nhật thuộc tính
        /// URL: Product/EditAttribute/{id}?attributeId=...
        /// </summary>
        [HttpGet]
        public IActionResult EditAttribute(int id, int attributeId)
        {
            return View();
        }

        /// <summary>
        /// Xử lý cập nhật thuộc tính của sản phẩm
        /// URL: Product/EditAttribute/{id}?attributeId=... (POST)
        /// </summary>
        [HttpPost]
        public IActionResult EditAttribute(int id, int attributeId, object model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // TODO: Cập nhật thuộc tính

            return RedirectToAction("ListAttributes", new { id = id });
        }

        /// <summary>
        /// Xóa thuộc tính khỏi sản phẩm
        /// URL: Product/DeleteAttribute/{id}?attributeId=...
        /// </summary>
        [HttpPost]
        public IActionResult DeleteAttribute(int id, int attributeId)
        {
            // TODO: Xóa thuộc tính

            return RedirectToAction("ListAttributes", new { id = id });
        }

        #endregion

        #region PHOTO

        /// <summary>
        /// Hiển thị danh sách hình ảnh của sản phẩm
        /// URL: Product/ListPhotos/{id}
        /// </summary>
        public IActionResult ListPhotos(int id)
        {
            return View();
        }

        /// <summary>
        /// Hiển thị form thêm ảnh cho sản phẩm
        /// URL: Product/CreatePhoto/{id} (GET)
        /// </summary>
        [HttpGet]
        public IActionResult CreatePhoto(int id)
        {
            return View();
        }

        /// <summary>
        /// Xử lý lưu ảnh mới cho sản phẩm
        /// URL: Product/CreatePhoto/{id} (POST)
        /// </summary>
        [HttpPost]
        public IActionResult CreatePhoto(int id, object model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // TODO: Lưu ảnh

            return RedirectToAction("ListPhotos", new { id = id });
        }

        /// <summary>
        /// Hiển thị form cập nhật ảnh
        /// URL: Product/EditPhoto/{id}?photoId=...
        /// </summary>
        [HttpGet]
        public IActionResult EditPhoto(int id, int photoId)
        {
            return View();
        }

        /// <summary>
        /// Xử lý cập nhật thông tin ảnh
        /// URL: Product/EditPhoto/{id}?photoId=... (POST)
        /// </summary>
        [HttpPost]
        public IActionResult EditPhoto(int id, int photoId, object model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // TODO: Cập nhật ảnh

            return RedirectToAction("ListPhotos", new { id = id });
        }

        /// <summary>
        /// xoá ảnh khỏi sản phẩm
        /// URL: Product/DeletePhoto/{id}?photoId=...
        /// </summary>
        [HttpPost]
        public IActionResult DeletePhoto(int id, int photoId)
        {
            // TODO: Xóa ảnh

            return RedirectToAction("ListPhotos", new { id = id });
        }

        #endregion
    }
}